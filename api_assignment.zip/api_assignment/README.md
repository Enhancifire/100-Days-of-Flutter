# OffsetFarm Internship Assignment

A project built to serve as assignment submission.

## Getting Started

- Get dependencies
  ```
  flutter pub get
  ```

- Run application
  ```
  flutter run
  ```

## Prebuilt Application

A prebuilt APK has been included in the root directory of this repository
